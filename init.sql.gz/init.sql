-- ⚠️ Se connecter à 'PG_DB' ⚠️ --
/*SET search_path TO $PG_DB;*/

CREATE TABLE role (
    label VARCHAR(25) PRIMARY KEY
);

CREATE TABLE country (
    name VARCHAR(20) PRIMARY KEY
);

CREATE TABLE city (
    zip_code INT,
    name VARCHAR(20),
    country VARCHAR(20) NOT NULL REFERENCES country(name),
    CONSTRAINT pk_city PRIMARY KEY (zip_code, name),
    CONSTRAINT zip_code_length CHECK (zip_code BETWEEN 1 AND 99999)
);

CREATE TABLE employee (
    id SMALLSERIAL PRIMARY KEY,
    first_name VARCHAR(20) NOT NULL,
    last_name VARCHAR(25) NOT NULL,
    password BYTEA NOT NULL,
    is_active BOOLEAN NOT NULL DEFAULT TRUE,
    street VARCHAR(30) NOT NULL,
    street_number VARCHAR(4) NOT NULL,
    unit_number SMALLINT,
    role_label VARCHAR(25) NOT NULL,
    hire_date DATE NOT NULL,
    manager_id SMALLINT REFERENCES employee(id),
    city_zip_code INT NOT NULL,
    city_name VARCHAR(20) NOT NULL,
    CONSTRAINT fk_employee_city FOREIGN KEY (city_zip_code, city_name) REFERENCES city(zip_code, name),
    CONSTRAINT unit_number_length CHECK (unit_number >= 1)
);

CREATE TABLE vat (
    type CHAR(1) PRIMARY KEY,
    rate SMALLINT NOT NULL,
    CONSTRAINT rate_range CHECK (rate BETWEEN 0 AND 100)
);

CREATE TABLE category (
    id SMALLSERIAL PRIMARY KEY,
    name VARCHAR(20) NOT NULL
);

CREATE TABLE brand (
    id SMALLSERIAL PRIMARY KEY,
    name VARCHAR(20) NOT NULL
);

CREATE TABLE product (
    barcode BIGINT PRIMARY KEY,
    name VARCHAR(60) NOT NULL,
    description TEXT,
    amount SMALLINT NOT NULL,
    is_available BOOLEAN NOT NULL DEFAULT TRUE,
    vat_type CHAR(1) NOT NULL REFERENCES vat(type),
    category_id SMALLINT NOT NULL REFERENCES category(id),
    brand_id SMALLINT NOT NULL REFERENCES brand(id),
    excl_vat_price MONEY NOT NULL,
    start_date DATE NOT NULL,
    CONSTRAINT excl_vat_price_range CHECK (excl_vat_price > 0)
);

CREATE TABLE customer (
    loyalty_card_number SERIAL PRIMARY KEY,
    first_name VARCHAR(20) NOT NULL,
    last_name VARCHAR(25) NOT NULL,
    birth_date DATE NOT NULL,
    email VARCHAR(50) NOT NULL,
    phone INT,
    vat_number BIGINT,
    loyalty_points SMALLINT NOT NULL DEFAULT 0,
    CONSTRAINT birth_date_past CHECK (birth_date < CURRENT_DATE),
    CONSTRAINT phone_positive CHECK (phone > 0),
    CONSTRAINT vat_number_positive CHECK (vat_number > 0),
    CONSTRAINT loyalty_points_not_negative CHECK (loyalty_points >= 0)
);

CREATE TABLE purchase (
    id BIGSERIAL PRIMARY KEY,
    date DATE NOT NULL,
    employee_id SMALLINT REFERENCES employee(id),
    customer_card_number INT REFERENCES customer(loyalty_card_number),
    CONSTRAINT date_check_not_future CHECK (date <= CURRENT_DATE)
);

CREATE TABLE order_line (
    quantity SMALLINT NOT NULL,
    product_barcode BIGINT REFERENCES product(barcode),
    purchase_id BIGINT NOT NULL REFERENCES purchase(id),
    CONSTRAINT pk_order_line PRIMARY KEY (product_barcode, purchase_id),
    CONSTRAINT quantity_positive CHECK (quantity > 0)
);
-- Script d'insertion des données de base --

INSERT INTO country (name) VALUES
    ('🇦🇫 Afghanistan'),
    ('🇿🇦 Afrique du Sud'),
    ('🇦🇱 Albanie'),
    ('🇩🇿 Algérie'),
    ('🇩🇪 Allemagne'),
    ('🇦🇩 Andorre'),
    ('🇦🇴 Angola'),
    ('🇦🇬 Antigua-et-Barbuda'),
    ('🇸🇦 Arabie saoudite'),
    ('🇦🇷 Argentine'),
    ('🇦🇲 Arménie'),
    ('🇦🇺 Australie'),
    ('🇦🇹 Autriche'),
    ('🇦🇿 Azerbaïdjan'),
    ('🇧🇸 Bahamas'),
    ('🇧🇭 Bahreïn'),
    ('🇧🇩 Bangladesh'),
    ('🇧🇧 Barbade'),
    ('🇧🇪 Belgique'),
    ('🇧🇿 Belize'),
    ('🇧🇯 Bénin'),
    ('🇧🇹 Bhoutan'),
    ('🇧🇾 Biélorussie'),
    ('🇲🇲 Birmanie'),
    ('🇧🇴 Bolivie'),
    ('🇧🇦 Bosnie-Herzégovine'),
    ('🇧🇼 Botswana'),
    ('🇧🇷 Brésil'),
    ('🇧🇳 Brunei'),
    ('🇧🇬 Bulgarie'),
    ('🇧🇫 Burkina Faso'),
    ('🇧🇮 Burundi'),
    ('🇰🇭 Cambodge'),
    ('🇨🇲 Cameroun'),
    ('🇨🇦 Canada'),
    ('🇨🇻 Cap-Vert'),
    ('🇨🇫 Centrafrique'),
    ('🇨🇱 Chili'),
    ('🇨🇳 Chine'),
    ('🇨🇾 Chypre'),
    ('🇨🇴 Colombie'),
    ('🇰🇲 Comores'),
    ('🇨🇬 Congo'),
    ('🇨🇩 Congo (RDC)'),
    ('🇰🇵 Corée du Nord'),
    ('🇰🇷 Corée du Sud'),
    ('🇨🇷 Costa Rica'),
    ('🇨🇮 Côte d''Ivoire'),
    ('🇭🇷 Croatie'),
    ('🇨🇺 Cuba'),
    ('🇩🇰 Danemark'),
    ('🇩🇯 Djibouti'),
    ('🇩🇲 Dominique'),
    ('🇪🇬 Égypte'),
    ('🇦🇪 Émirats arabes unis'),
    ('🇪🇨 Équateur'),
    ('🇪🇷 Érythrée'),
    ('🇪🇸 Espagne'),
    ('🇪🇪 Estonie'),
    ('🇸🇿 Eswatini'),
    ('🇺🇸 États-Unis'),
    ('🇪🇹 Éthiopie'),
    ('🇫🇯 Fidji'),
    ('🇫🇮 Finlande'),
    ('🇫🇷 France'),
    ('🇬🇦 Gabon'),
    ('🇬🇲 Gambie'),
    ('🇬🇪 Géorgie'),
    ('🇬🇭 Ghana'),
    ('🇬🇷 Grèce'),
    ('🇬🇩 Grenade'),
    ('🇬🇹 Guatemala'),
    ('🇬🇳 Guinée'),
    ('🇬🇶 Guinée équatoriale'),
    ('🇬🇼 Guinée-Bissau'),
    ('🇬🇾 Guyana'),
    ('🇭🇹 Haïti'),
    ('🇭🇳 Honduras'),
    ('🇭🇺 Hongrie'),
    ('🇲🇭 Îles Marshall'),
    ('🇸🇧 Îles Salomon'),
    ('🇮🇳 Inde'),
    ('🇮🇩 Indonésie'),
    ('🇮🇶 Irak'),
    ('🇮🇷 Iran'),
    ('🇮🇪 Irlande'),
    ('🇮🇸 Islande'),
    ('🇮🇱 Israël'),
    ('🇮🇹 Italie'),
    ('🇯🇲 Jamaïque'),
    ('🇯🇵 Japon'),
    ('🇯🇴 Jordanie'),
    ('🇰🇿 Kazakhstan'),
    ('🇰🇪 Kenya'),
    ('🇰🇬 Kirghizistan'),
    ('🇰🇮 Kiribati'),
    ('🇽🇰 Kosovo'),
    ('🇰🇼 Koweït'),
    ('🇱🇦 Laos'),
    ('🇱🇸 Lesotho'),
    ('🇱🇻 Lettonie'),
    ('🇱🇧 Liban'),
    ('🇱🇷 Liberia'),
    ('🇱🇾 Libye'),
    ('🇱🇮 Liechtenstein'),
    ('🇱🇹 Lituanie'),
    ('🇱🇺 Luxembourg'),
    ('🇲🇰 Macédoine du Nord'),
    ('🇲🇬 Madagascar'),
    ('🇲🇾 Malaisie'),
    ('🇲🇼 Malawi'),
    ('🇲🇻 Maldives'),
    ('🇲🇱 Mali'),
    ('🇲🇹 Malte'),
    ('🇲🇦 Maroc'),
    ('🇲🇺 Maurice'),
    ('🇲🇷 Mauritanie'),
    ('🇲🇽 Mexique'),
    ('🇫🇲 Micronésie'),
    ('🇲🇩 Moldavie'),
    ('🇲🇨 Monaco'),
    ('🇲🇳 Mongolie'),
    ('🇲🇪 Monténégro'),
    ('🇲🇿 Mozambique'),
    ('🇳🇦 Namibie'),
    ('🇳🇷 Nauru'),
    ('🇳🇵 Népal'),
    ('🇳🇮 Nicaragua'),
    ('🇳🇪 Niger'),
    ('🇳🇬 Nigeria'),
    ('🇳🇴 Norvège'),
    ('🇳🇿 Nouvelle-Zélande'),
    ('🇴🇲 Oman'),
    ('🇺🇬 Ouganda'),
    ('🇺🇿 Ouzbékistan'),
    ('🇵🇰 Pakistan'),
    ('🇵🇼 Palaos'),
    ('🇵🇸 Palestine'),
    ('🇵🇦 Panama'),
    ('🇵🇬 Papouasie-Nlle-Guinée'),
    ('🇵🇾 Paraguay'),
    ('🇳🇱 Pays-Bas'),
    ('🇵🇪 Pérou'),
    ('🇵🇭 Philippines'),
    ('🇵🇱 Pologne'),
    ('🇵🇹 Portugal'),
    ('🇶🇦 Qatar'),
    ('🇷🇴 Roumanie'),
    ('🇬🇧 Royaume-Uni'),
    ('🇷🇺 Russie'),
    ('🇷🇼 Rwanda'),
    ('🇰🇳 Saint-Kitts-et-Nevis'),
    ('🇸🇲 Saint-Marin'),
    ('🇻🇨 Saint-Vincent'),
    ('🇱🇨 Sainte-Lucie'),
    ('🇸🇻 Salvador'),
    ('🇼🇸 Samoa'),
    ('🇸🇹 São Tomé-et-Principe'),
    ('🇸🇳 Sénégal'),
    ('🇷🇸 Serbie'),
    ('🇸🇨 Seychelles'),
    ('🇸🇱 Sierra Leone'),
    ('🇸🇬 Singapour'),
    ('🇸🇰 Slovaquie'),
    ('🇸🇮 Slovénie'),
    ('🇸🇴 Somalie'),
    ('🇸🇩 Soudan'),
    ('🇸🇸 Soudan du Sud'),
    ('🇱🇰 Sri Lanka'),
    ('🇸🇪 Suède'),
    ('🇨🇭 Suisse'),
    ('🇸🇷 Suriname'),
    ('🇸🇾 Syrie'),
    ('🇹🇯 Tadjikistan'),
    ('🇹🇼 Taïwan'),
    ('🇹🇿 Tanzanie'),
    ('🇹🇩 Tchad'),
    ('🇨🇿 Tchéquie'),
    ('🇹🇭 Thaïlande'),
    ('🇹🇱 Timor oriental'),
    ('🇹🇬 Togo'),
    ('🇹🇴 Tonga'),
    ('🇹🇹 Trinité-et-Tobago'),
    ('🇹🇳 Tunisie'),
    ('🇹🇲 Turkménistan'),
    ('🇹🇷 Turquie'),
    ('🇹🇻 Tuvalu'),
    ('🇺🇦 Ukraine'),
    ('🇺🇾 Uruguay'),
    ('🇻🇺 Vanuatu'),
    ('🇻🇦 Vatican'),
    ('🇻🇪 Venezuela'),
    ('🇻🇳 Viêt Nam'),
    ('🇾🇪 Yémen'),
    ('🇿🇲 Zambie'),
    ('🇿🇼 Zimbabwe')
;

INSERT INTO vat (type, rate) VALUES
('A', 21),  -- Taux standard
('B', 12),  -- Taux intermédiaire
('C', 6),   -- Taux réduit
('D', 0);   -- Exonéré

INSERT INTO category (name) VALUES
('Alimentation'),
('Électronique'),
('Vêtements'),
('Livres'),
('Meubles'),
('Santé'),
('Beauté'),
('Sports'),
('Jardinage'),
('Jouets'),
('Bricolage'),
('Animalerie'),
('Automobile');

INSERT INTO brand (name) VALUES
('Samsung'),
('Delhaize Selection'),
('Gardena'),
('Apple'),
('Sony');

INSERT INTO product (barcode, name, description, amount, is_available, vat_type, category_id, brand_id, excl_vat_price, start_date) VALUES
(5901234123457, 'Smartphone Galaxy S22', 'Smartphone haut de gamme avec écran AMOLED 6.1"', 25, TRUE, 'A', 2, 1, '799.99', '2023-01-01'),
(4007817327098, 'Chocolat noir 70%', 'Tablette de chocolat noir pur beurre de cacao', 150, TRUE, 'B', 1, 2, '2.49', '2023-01-01'),
(8711495392919, 'Sécateur Gardena', 'Sécateur de jardin ergonomique', 32, TRUE, 'A', 9, 3, '24.99', '2023-01-01'),
(7350073733347, 'iPad Pro', 'Tablette tactile 11 pouces', 18, TRUE, 'A', 2, 4, '999.99', '2023-01-01'),
(4902505854453, 'Casque WH-1000XM5', 'Casque à réduction de bruit', 12, FALSE, 'A', 2, 5, '349.99', '2023-01-01');

INSERT INTO role (label) VALUES
('ADMIN'),
('CASHIER');

INSERT INTO city (zip_code, name, country) VALUES
(1000, 'Bruxelles', '🇧🇪 Belgique'),
(1050, 'Ixelles', '🇧🇪 Belgique');

INSERT INTO employee (first_name, last_name, password, is_active, street, street_number, unit_number, role_label, hire_date, manager_id, city_zip_code, city_name) VALUES
('Jean', 'Dupont', E'\\x70617373776F726431323300', TRUE, 'Rue de la Loi', '10', NULL, 'ADMIN', '2020-01-15', NULL, 1000, 'Bruxelles'),
('Pierre', 'Durand', E'\\x70617373776F726431323300', TRUE, 'Rue Neuve', '42B', NULL, 'CASHIER', '2021-03-10', 1, 1050, 'Ixelles');

INSERT INTO customer (first_name, last_name, birth_date, email, phone, vat_number, loyalty_points) VALUES
('Michel', 'Leroy', '1985-03-12', 'michel.leroy@email.com', 0471234567, NULL, 150),
('Camille', 'Dubois', '1992-07-25', 'camille.dubois@email.com', 0489654321, NULL, 75);

INSERT INTO purchase (date, employee_id, customer_card_number) VALUES
('2023-10-15', 1, 1),
('2023-10-16', 2, 2);

INSERT INTO order_line (quantity, product_barcode, purchase_id) VALUES
(1, 5901234123457, 1),  -- Smartphone dans achat 1
(2, 4007817327098, 1),  -- Chocolat dans achat 1
(1, 8711495392919, 1),  -- Sécateur dans achat 1
(1, 7350073733347, 2),  -- iPad dans achat 2
(1, 4902505854453, 2);  -- Casque dans achat 2
